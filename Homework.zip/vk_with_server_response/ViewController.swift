//
//  ViewController.swift
//  vk_with_server_response
//
//  Created by user155176 on 18/09/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}



