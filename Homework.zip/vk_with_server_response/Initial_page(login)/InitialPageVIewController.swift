//
//  ViewController.swift
//  vk_with_server_response
//
//  Created by user155176 on 18/09/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import UIKit
import WebKit
import Alamofire


struct Session{
    var token = ""
    var user_id = ""
    var expire_in = ""
}

class InitialPageViewController: UIViewController {
var tokenn = Session()
    
    @IBOutlet weak var initialWebView: WKWebView! {
        didSet{
            initialWebView.navigationDelegate = self
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var urlComponents = URLComponents()
        urlComponents.scheme = "https"
        urlComponents.host = "oauth.vk.com"
        urlComponents.path = "/authorize"
        urlComponents.queryItems = [
            URLQueryItem(name: "client_id", value: "7139020"),
            URLQueryItem(name: "display", value: "mobile"),
            URLQueryItem(name: "redirect_uri", value: "https://oauth.vk.com/blank.html"),
            URLQueryItem(name: "scope", value: "262150"),
            URLQueryItem(name: "response_type", value: "token"),
            URLQueryItem(name: "v", value: "5.68")
        ]
        
        let request = URLRequest(url: urlComponents.url!)
        
        initialWebView.load(request)
        self.view.backgroundColor = .yellow
        
       /*
        let urlInfo = URL(string: "https://api.vk.com/method/users.get?user_ids=\(tokenn.user_id)&fields=bdate&access_token=\(tokenn.token)&v=5.101")
        
        let session = URLSession.shared
        let task = session.dataTask(with: urlInfo!) { (data, response, error) in
            // в замыкании данные, полученные от сервера, мы преобразуем в json
            let json = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
            // выводим в консоль
            print(json)
        }
        task.resume()
        print(task)
      
    */
        
        // Do any additional setup after loading the view.
    
       

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
}
extension InitialPageViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        
        guard let url = navigationResponse.response.url, url.path == "/blank.html", let fragment = url.fragment  else {
            decisionHandler(.allow)
            return
        }
        
        let params = fragment
            .components(separatedBy: "&")
            .map { $0.components(separatedBy: "=") }
            .reduce([String: String]()) { result, param in
                var dict = result
                let key = param[0]
                let value = param[1]
                dict[key] = value
                return dict
        }
        

        
        let token = params["access_token"]
        tokenn.token = params["access_token"] ?? ""
        tokenn.user_id = params["user_id"] ?? ""
        tokenn.expire_in = params["expires_in"] ?? ""
        
        print(token ?? "error")
      //  print(params)
        
        //////////////////////////
      /*  let urlInfo = URL(string: "https://api.vk.com/method/users.get?user_ids=\(tokenn.user_id)&fields=bdate&access_token=\(tokenn.token)&v=5.101")
        
        let session = URLSession.shared
        let task = session.dataTask(with: urlInfo!) { (data, response, error) in
            // в замыкании данные, полученные от сервера, мы преобразуем в json
            let json = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
            // выводим в консоль
            print(json)
        }
        task.resume()
        */
        /* let uirlFriends = URL(string: "https://api.vk.com/method/users.getFollowers?user_ids=\(tokenn.user_id)&count=2&fields=photo_50&access_token=\(tokenn.token)&v=5.101")
        let session2 = URLSession.shared
        let task2 = session.dataTask(with: uirlFriends!) { (data, response, error) in
            // в замыкании данные, полученные от сервера, мы преобразуем в json
            let json = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
            // выводим в консоль
            print(json)
        }
        task2.resume()
       */
        
        
        ///////--------------------

        struct List:Codable {
            
        }
        struct Response:Codable{
            let response: SubList?
            
        }
        struct SubList: Codable{
            let count:Int?
            let items: UserClass?
        }
        struct UserClass: Codable {
            let id: Int?
            let first_name: String?
            let second_name: String?
            let city:Cities?
        }
        struct Cities:Codable{
            let id: Int?
            let city:String?
        }
 
      
        
        
        func tryRequest(_ url:String) -> () {
             let urlRequest = URL(string: url)
            let session = URLSession.shared
            let task = session.dataTask(with: urlRequest!) { (data, response, error) in
                // в замыкании данные, полученные от сервера, мы преобразуем в json
             //  let json = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                // выводим в консоль
                guard let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) else  {return}
                
                let array = json as! [String:[String:Any]]
                print(array)
               // print(array["response"]!["items"])
        
                
             
             /*   for key in array{
                    let key = key["response"]
                      for value in array[key]
                         let value = value["items"]
                    print(
                }*/
               /* do{
                    let array2 = try JSONDecoder().decode(Response.self, from: data )
                print(array2)
                }
                catch{
                    print(error.localizedDescription)
                }
*/
 
                /*
                 if let dictionary = jsonWithObjectRoot as? [String: Any] {
                 if let number = dictionary["someKey"] as? Double {
                 // access individual value in dictionary
                 }
                 
                 for (key, value) in dictionary {
                 // access all key / value pairs in dictionary
                 }
                
                */
                
                
               // print(json)
                }.resume()
            
        }
        tryRequest("https://api.vk.com/method/account.getProfileInfo?user_ids=\(tokenn.user_id)&fields=bdate&country=title&access_token=\(tokenn.token)&v=5.101")
        tryRequest("https://api.vk.com/method/friends.get?user_ids=\(tokenn.user_id)&order=name&count=1&fields=city,domain&name_case=ins&access_token=\(tokenn.token)&v=5.101")
        
        
        
        /////////////////
        
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let friendsStoryBoard = mainStoryBoard.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController        //friendsStoryBoard.user?.image = usersAva[indexPath.row]
        // friendsStoryBoard.userName?.text = contacts[indexPath.row]
        
        self.navigationController?.pushViewController(friendsStoryBoard, animated: true)
        
        
        
        
        decisionHandler(.cancel)
    }

   
}


