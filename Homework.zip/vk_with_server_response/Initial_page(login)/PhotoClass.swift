//
//  PhotoClass.swift
//  vk_with_server_response
//
//  Created by user155176 on 21/09/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import Foundation
