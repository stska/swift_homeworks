//
//  UserClass.swift
//  vk_with_server_response
//
//  Created by user155176 on 21/09/2019.
//  Copyright © 2019 user155176. All rights reserved.
//

import Foundation


struct Response:Codable{
    let response: SubList?
}
struct SubList: Codable{
    let count:Int?
    let items: UserClass?
}
struct UserClass: Codable {
    let id: Int?
    let first_name: String?
    let second_name: String?
    let city:Cities?
}
struct Cities:Codable{
    let id: Int?
    let city:String?
}



